The main function(ADAD3400_Ass_v3) should be run with Motion_Tracking_oscP5send at the same time.

Of course if only the main function is run alone, no error will happen but also no interaction will happen.